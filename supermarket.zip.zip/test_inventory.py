from tools.inventory import (
    add_product,
    receive_stock,
    get_stock,
    get_low_stock
)


def main():

    print("\n1. Adding product...")
    result = add_product(
        name="Maggi 70g",
        unit="packet",
        cost_price=12,
        sell_price=14,
        mrp=14,
        quantity=5,
        reorder_level=5,
        gst_rate=12,
        hsn_code="TEST"
    )
    print(result)

    print("\n2. Checking stock...")
    stock = get_stock("Maggi 70g")
    print(stock)

    if stock["success"]:
        product_id = stock["products"][0]["id"]

        print("\n3. Checking low stock...")
        print(get_low_stock())

        print("\n4. Receiving 5 more packets...")
        print(receive_stock(product_id, 5))

        print("\n5. Checking stock again...")
        print(get_stock("Maggi 70g"))

        print("\n6. Checking low stock again...")
        print(get_low_stock())


if __name__ == "__main__":
    main()