from tools.billing import finalize_bill, get_bill
from tools.inventory import get_stock


def main():

    bill_id = 7

    print("\n1. Stock before finalization...")

    print(get_stock("Maggi 70g"))
    print(get_stock("Tata Salt"))

    print("\n2. Finalizing Bill #7...")

    result = finalize_bill(
        bill_id=bill_id,
        payment_mode="upi",
        payment_reference="GST_UPI_TEST_001"
    )

    print(result)

    print("\n3. Getting finalized bill...")

    print(get_bill(bill_id))

    print("\n4. Stock after finalization...")

    print(get_stock("Maggi 70g"))
    print(get_stock("Tata Salt"))


if __name__ == "__main__":
    main()