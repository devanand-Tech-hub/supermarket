from tools.inventory import add_product


def main():
    print("\nAdding Tata Salt...")

    result = add_product(
        name="Tata Salt",
        unit="packet",
        cost_price=20,
        sell_price=25,
        mrp=25,
        quantity=10,
        reorder_level=3,
        gst_rate=5,
        hsn_code="TEST"
    )

    print(result)


if __name__ == "__main__":
    main()