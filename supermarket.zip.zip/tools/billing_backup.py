from app.database import get_connection


def calculate_gst(base_amount, gst_rate):
    """Calculate GST, CGST and SGST with 2-decimal rounding."""

    gst_amount = round(base_amount * gst_rate / 100, 2)

    # Split GST equally between CGST and SGST
    cgst_amount = round(gst_amount / 2, 2)
    sgst_amount = round(gst_amount - cgst_amount, 2)

    return gst_amount, cgst_amount, sgst_amount


def create_bill(customer_name=None):
    conn = get_connection()

    try:
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO bills (
                customer_name,
                subtotal,
                gst_amount,
                cgst_amount,
                sgst_amount,
                total_amount,
                status
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            customer_name,
            0,
            0,
            0,
            0,
            0,
            "draft"
        ))

        bill_id = cursor.lastrowid

        conn.commit()

        return {
            "success": True,
            "message": "Draft bill created successfully.",
            "bill_id": bill_id,
            "customer_name": customer_name,
            "status": "draft"
        }

    except Exception as e:
        conn.rollback()

        return {
            "success": False,
            "message": str(e)
        }

    finally:
        conn.close()


def add_bill_item(bill_id, product_id, quantity):
    conn = get_connection()

    try:
        cursor = conn.cursor()

        # Check bill
        cursor.execute("""
            SELECT id, status
            FROM bills
            WHERE id = ?
        """, (bill_id,))

        bill = cursor.fetchone()

        if bill is None:
            return {
                "success": False,
                "message": "Bill not found."
            }

        if bill["status"] != "draft":
            return {
                "success": False,
                "message": "Items can only be added to a draft bill."
            }

        # Check quantity
        if quantity <= 0:
            return {
                "success": False,
                "message": "Quantity must be greater than zero."
            }

        # Get product
        cursor.execute("""
            SELECT
                id,
                name,
                quantity,
                sell_price,
                gst_rate
            FROM products
            WHERE id = ?
        """, (product_id,))

        product = cursor.fetchone()

        if product is None:
            return {
                "success": False,
                "message": "Product not found."
            }

        # Check available stock
        if product["quantity"] < quantity:
            return {
                "success": False,
                "message": (
                    f"Cannot add {quantity} units of {product['name']}. "
                    f"Only {product['quantity']} units are available."
                )
            }

        # Calculate values
        unit_price = product["sell_price"]
        gst_rate = product["gst_rate"]

        base_amount = round(unit_price * quantity, 2)

        gst_amount, cgst_amount, sgst_amount = calculate_gst(
            base_amount,
            gst_rate
        )

        line_total = round(base_amount + gst_amount, 2)

        # Add item
        cursor.execute("""
            INSERT INTO bill_items (
                bill_id,
                product_id,
                product_name,
                quantity,
                unit_price,
                gst_rate,
                gst_amount,
                line_total
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            bill_id,
            product["id"],
            product["name"],
            quantity,
            unit_price,
            gst_rate,
            gst_amount,
            line_total
        ))

        # Recalculate bill totals
        cursor.execute("""
            SELECT
                COALESCE(SUM(quantity * unit_price), 0) AS subtotal,
                COALESCE(SUM(gst_amount), 0) AS gst_amount,
                COALESCE(SUM(line_total), 0) AS total_amount
            FROM bill_items
            WHERE bill_id = ?
        """, (bill_id,))

        totals = cursor.fetchone()

        subtotal = round(totals["subtotal"], 2)
        total_gst = round(totals["gst_amount"], 2)
        total_amount = round(totals["total_amount"], 2)

        # Calculate complete bill CGST / SGST
        cgst_total = round(total_gst / 2, 2)
        sgst_total = round(total_gst - cgst_total, 2)

        cursor.execute("""
            UPDATE bills
            SET subtotal = ?,
                gst_amount = ?,
                cgst_amount = ?,
                sgst_amount = ?,
                total_amount = ?
            WHERE id = ?
        """, (
            subtotal,
            total_gst,
            cgst_total,
            sgst_total,
            total_amount,
            bill_id
        ))

        conn.commit()

        return {
            "success": True,
            "message": (
                f"{quantity} units of {product['name']} "
                f"added to bill."
            ),
            "bill_id": bill_id,
            "product": product["name"],
            "quantity": quantity,
            "unit_price": unit_price,
            "gst_rate": gst_rate,
            "gst_amount": gst_amount,
            "cgst_amount": cgst_amount,
            "sgst_amount": sgst_amount,
            "line_total": line_total,
            "subtotal": subtotal,
            "total_gst": total_gst,
            "cgst_total": cgst_total,
            "sgst_total": sgst_total,
            "total_amount": total_amount
        }

    except Exception as e:
        conn.rollback()

        return {
            "success": False,
            "message": str(e)
        }

    finally:
        conn.close()


def get_bill(bill_id):
    conn = get_connection()

    try:
        cursor = conn.cursor()

        # Get bill details
        cursor.execute("""
            SELECT
                id,
                customer_name,
                subtotal,
                gst_amount,
                cgst_amount,
                sgst_amount,
                total_amount,
                payment_mode,
                payment_reference,
                status,
                created_at
            FROM bills
            WHERE id = ?
        """, (bill_id,))

        bill = cursor.fetchone()

        if bill is None:
            return {
                "success": False,
                "message": "Bill not found."
            }

        # Get bill items
        cursor.execute("""
            SELECT
                id,
                product_id,
                product_name,
                quantity,
                unit_price,
                gst_rate,
                gst_amount,
                line_total
            FROM bill_items
            WHERE bill_id = ?
            ORDER BY id
        """, (bill_id,))

        items = cursor.fetchall()

        bill_data = dict(bill)

        # Ensure clean 2-decimal values
        bill_data["subtotal"] = round(bill_data["subtotal"], 2)
        bill_data["gst_amount"] = round(bill_data["gst_amount"], 2)
        bill_data["cgst_amount"] = round(bill_data["cgst_amount"], 2)
        bill_data["sgst_amount"] = round(bill_data["sgst_amount"], 2)
        bill_data["total_amount"] = round(bill_data["total_amount"], 2)

        item_data = []

        for item in items:
            data = dict(item)

            data["quantity"] = round(data["quantity"], 2)
            data["unit_price"] = round(data["unit_price"], 2)
            data["gst_rate"] = round(data["gst_rate"], 2)
            data["gst_amount"] = round(data["gst_amount"], 2)
            data["line_total"] = round(data["line_total"], 2)

            item_data.append(data)

        return {
            "success": True,
            "bill": bill_data,
            "items": item_data
        }

    finally:
        conn.close()


def update_bill_item(bill_item_id, quantity):
    conn = get_connection()

    try:
        cursor = conn.cursor()

        # Check quantity
        if quantity <= 0:
            return {
                "success": False,
                "message": "Quantity must be greater than zero."
            }

        # Get bill item and bill status
        cursor.execute("""
            SELECT
                bi.id,
                bi.bill_id,
                bi.product_id,
                bi.product_name,
                bi.unit_price,
                bi.gst_rate,
                b.status
            FROM bill_items bi
            JOIN bills b ON bi.bill_id = b.id
            WHERE bi.id = ?
        """, (bill_item_id,))

        item = cursor.fetchone()

        if item is None:
            return {
                "success": False,
                "message": "Bill item not found."
            }

        # Only draft bills can be edited
        if item["status"] != "draft":
            return {
                "success": False,
                "message": "Only draft bills can be edited."
            }

        # Check current stock
        cursor.execute("""
            SELECT quantity
            FROM products
            WHERE id = ?
        """, (item["product_id"],))

        product = cursor.fetchone()

        if product is None:
            return {
                "success": False,
                "message": "Product not found."
            }

        if product["quantity"] < quantity:
            return {
                "success": False,
                "message": (
                    f"Cannot set quantity to {quantity}. "
                    f"Only {product['quantity']} units are available."
                )
            }

        # Recalculate item
        base_amount = round(item["unit_price"] * quantity, 2)

        gst_amount, cgst_amount, sgst_amount = calculate_gst(
            base_amount,
            item["gst_rate"]
        )

        line_total = round(base_amount + gst_amount, 2)

        # Update item
        cursor.execute("""
            UPDATE bill_items
            SET quantity = ?,
                gst_amount = ?,
                line_total = ?
            WHERE id = ?
        """, (
            quantity,
            gst_amount,
            line_total,
            bill_item_id
        ))

        # Recalculate bill
        cursor.execute("""
            SELECT
                COALESCE(SUM(quantity * unit_price), 0) AS subtotal,
                COALESCE(SUM(gst_amount), 0) AS gst_amount,
                COALESCE(SUM(line_total), 0) AS total_amount
            FROM bill_items
            WHERE bill_id = ?
        """, (item["bill_id"],))

        totals = cursor.fetchone()

        subtotal = round(totals["subtotal"], 2)
        total_gst = round(totals["gst_amount"], 2)
        total_amount = round(totals["total_amount"], 2)

        cgst_total = round(total_gst / 2, 2)
        sgst_total = round(total_gst - cgst_total, 2)

        cursor.execute("""
            UPDATE bills
            SET subtotal = ?,
                gst_amount = ?,
                cgst_amount = ?,
                sgst_amount = ?,
                total_amount = ?
            WHERE id = ?
        """, (
            subtotal,
            total_gst,
            cgst_total,
            sgst_total,
            total_amount,
            item["bill_id"]
        ))

        conn.commit()

        return {
            "success": True,
            "message": (
                f"{item['product_name']} quantity "
                f"updated to {quantity}."
            ),
            "bill_id": item["bill_id"],
            "product": item["product_name"],
            "quantity": quantity,
            "gst_amount": gst_amount,
            "cgst_amount": cgst_amount,
            "sgst_amount": sgst_amount,
            "subtotal": subtotal,
            "total_gst": total_gst,
            "cgst_total": cgst_total,
            "sgst_total": sgst_total,
            "total_amount": total_amount
        }

    except Exception as e:
        conn.rollback()

        return {
            "success": False,
            "message": str(e)
        }

    finally:
        conn.close()


def remove_bill_item(bill_item_id):
    conn = get_connection()

    try:
        cursor = conn.cursor()

        # Get bill item and bill status
        cursor.execute("""
            SELECT
                bi.id,
                bi.bill_id,
                bi.product_name,
                b.status
            FROM bill_items bi
            JOIN bills b ON bi.bill_id = b.id
            WHERE bi.id = ?
        """, (bill_item_id,))

        item = cursor.fetchone()

        if item is None:
            return {
                "success": False,
                "message": "Bill item not found."
            }

        # Only draft bills can be edited
        if item["status"] != "draft":
            return {
                "success": False,
                "message": "Only draft bills can be edited."
            }

        # Remove item
        cursor.execute("""
            DELETE FROM bill_items
            WHERE id = ?
        """, (bill_item_id,))

        # Recalculate bill
        cursor.execute("""
            SELECT
                COALESCE(SUM(quantity * unit_price), 0) AS subtotal,
                COALESCE(SUM(gst_amount), 0) AS gst_amount,
                COALESCE(SUM(line_total), 0) AS total_amount
            FROM bill_items
            WHERE bill_id = ?
        """, (item["bill_id"],))

        totals = cursor.fetchone()

        subtotal = round(totals["subtotal"], 2)
        total_gst = round(totals["gst_amount"], 2)
        total_amount = round(totals["total_amount"], 2)

        cgst_total = round(total_gst / 2, 2)
        sgst_total = round(total_gst - cgst_total, 2)

        cursor.execute("""
            UPDATE bills
            SET subtotal = ?,
                gst_amount = ?,
                cgst_amount = ?,
                sgst_amount = ?,
                total_amount = ?
            WHERE id = ?
        """, (
            subtotal,
            total_gst,
            cgst_total,
            sgst_total,
            total_amount,
            item["bill_id"]
        ))

        conn.commit()

        return {
            "success": True,
            "message": f"{item['product_name']} removed from bill.",
            "bill_id": item["bill_id"],
            "subtotal": subtotal,
            "total_gst": total_gst,
            "cgst_total": cgst_total,
            "sgst_total": sgst_total,
            "total_amount": total_amount
        }

    except Exception as e:
        conn.rollback()

        return {
            "success": False,
            "message": str(e)
        }

    finally:
        conn.close()


def finalize_bill(
    bill_id,
    payment_mode,
    payment_amount,
    payment_reference=None
):
    conn = get_connection()

    try:
        cursor = conn.cursor()

        conn.execute("BEGIN")

        # Get bill
        cursor.execute("""
            SELECT
                id,
                customer_name,
                subtotal,
                gst_amount,
                cgst_amount,
                sgst_amount,
                total_amount,
                status
            FROM bills
            WHERE id = ?
        """, (bill_id,))

        bill = cursor.fetchone()

        if bill is None:
            conn.rollback()
            return {
                "success": False,
                "message": "Bill not found."
            }

        # Bill must be draft
        if bill["status"] != "draft":
            conn.rollback()
            return {
                "success": False,
                "message": "Only draft bills can be finalized."
            }

        # Get bill items
        cursor.execute("""
            SELECT
                product_id,
                product_name,
                quantity
            FROM bill_items
            WHERE bill_id = ?
        """, (bill_id,))

        items = cursor.fetchall()

        if not items:
            conn.rollback()
            return {
                "success": False,
                "message": "Cannot finalize an empty bill."
            }

        # Validate payment mode
        allowed_modes = ["cash", "upi", "card"]

        if not payment_mode:
            conn.rollback()
            return {
                "success": False,
                "message": "Payment mode is required."
            }

        payment_mode = payment_mode.lower().strip()

        if payment_mode not in allowed_modes:
            conn.rollback()
            return {
                "success": False,
                "message": (
                    "Invalid payment mode. "
                    "Use cash, upi, or card."
                )
            }

        # Validate payment amount
        if payment_amount is None:
            conn.rollback()
            return {
                "success": False,
                "message": "Payment amount is required."
            }

        try:
            payment_amount = float(payment_amount)
        except (TypeError, ValueError):
            conn.rollback()
            return {
                "success": False,
                "message": "Payment amount must be a valid number."
            }

        if payment_amount <= 0:
            conn.rollback()
            return {
                "success": False,
                "message": "Payment amount must be greater than zero."
            }

        # Check payment against bill total
        total_amount = round(bill["total_amount"], 2)

        if payment_amount < total_amount:
            conn.rollback()

            remaining = round(
                total_amount - payment_amount,
                2
            )

            return {
                "success": False,
                "message": (
                    f"Insufficient payment. "
                    f"Bill total: ₹{total_amount:.2f}, "
                    f"Paid: ₹{payment_amount:.2f}, "
                    f"Remaining: ₹{remaining:.2f}."
                )
            }

        # Calculate change
        change_amount = round(
            payment_amount - total_amount,
            2
        )

        # Check stock for every item
        for item in items:

            cursor.execute("""
                SELECT name, quantity
                FROM products
                WHERE id = ?
            """, (item["product_id"],))

            product = cursor.fetchone()

            if product is None:
                conn.rollback()
                return {
                    "success": False,
                    "message": (
                        f"Product {item['product_name']} "
                        f"not found."
                    )
                }

            if product["quantity"] < item["quantity"]:
                conn.rollback()
                return {
                    "success": False,
                    "message": (
                        f"Cannot finalize bill. "
                        f"Insufficient stock for "
                        f"{product['name']}. "
                        f"Required: {item['quantity']}, "
                        f"Available: {product['quantity']}."
                    )
                }

        # Deduct stock
        for item in items:

            cursor.execute("""
                UPDATE products
                SET quantity = quantity - ?
                WHERE id = ?
            """, (
                item["quantity"],
                item["product_id"]
            ))

        # Update bill with payment information
        cursor.execute("""
            UPDATE bills
            SET payment_mode = ?,
                payment_amount = ?,
                payment_reference = ?,
                status = 'finalized'
            WHERE id = ?
        """, (
            payment_mode,
            payment_amount,
            payment_reference,
            bill_id
        ))

        conn.commit()

        return {
            "success": True,
            "message": f"Bill #{bill_id} finalized successfully.",
            "bill_id": bill_id,
            "customer_name": bill["customer_name"],
            "subtotal": round(bill["subtotal"], 2),
            "gst_amount": round(bill["gst_amount"], 2),
            "cgst_amount": round(bill["cgst_amount"], 2),
            "sgst_amount": round(bill["sgst_amount"], 2),
            "total_amount": total_amount,
            "payment_mode": payment_mode,
            "payment_amount": round(payment_amount, 2),
            "change_amount": change_amount,
            "payment_reference": payment_reference,
            "status": "finalized"
        }

    except Exception as e:
        conn.rollback()

        return {
            "success": False,
            "message": str(e)
        }

    finally:
        conn.close()