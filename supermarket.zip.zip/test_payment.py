from tools.billing import (
    create_bill,
    add_bill_item,
    finalize_bill
)


def main():

    print("\n1. Creating payment test bill...")

    bill = create_bill("Payment Test Customer")
    print(bill)

    if not bill["success"]:
        return

    bill_id = bill["bill_id"]

    print("\n2. Adding 2 Maggi 70g...")

    result = add_bill_item(
        bill_id=bill_id,
        product_id=1,
        quantity=2
    )

    print(result)

    print("\n3. Testing insufficient payment...")

    result = finalize_bill(
        bill_id=bill_id,
        payment_mode="cash",
        payment_amount=20
    )

    print(result)

    print("\n4. Testing sufficient payment with change...")

    result = finalize_bill(
        bill_id=bill_id,
        payment_mode="cash",
        payment_amount=35
    )

    print(result)


if __name__ == "__main__":
    main()