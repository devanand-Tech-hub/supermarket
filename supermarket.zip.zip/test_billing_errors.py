from tools.billing import (
    create_bill,
    add_bill_item,
    update_bill_item,
    remove_bill_item,
    finalize_bill
)


def main():

    print("\n1. Trying to edit finalized Bill #4...")

    result = update_bill_item(
        bill_item_id=3,
        quantity=1
    )
    print(result)


    print("\n2. Trying to remove item from finalized Bill #4...")

    result = remove_bill_item(
        bill_item_id=3
    )
    print(result)


    print("\n3. Trying to finalize Bill #4 again...")

    result = finalize_bill(
        bill_id=4,
        payment_mode="cash"
    )
    print(result)


    print("\n4. Creating an empty bill...")

    bill = create_bill("Test Customer")
    print(bill)

    if bill["success"]:
        empty_bill_id = bill["bill_id"]

        print("\n5. Trying to finalize empty bill...")

        result = finalize_bill(
            bill_id=empty_bill_id,
            payment_mode="cash"
        )
        print(result)


    print("\n6. Creating a bill with insufficient stock...")

    bill = create_bill("Stock Test")
    print(bill)

    if bill["success"]:
        stock_test_bill_id = bill["bill_id"]

        print("\n7. Adding 100 Maggi packets...")

        result = add_bill_item(
            bill_id=stock_test_bill_id,
            product_id=1,
            quantity=100
        )
        print(result)

        print("\n8. Trying to finalize insufficient-stock bill...")

        result = finalize_bill(
            bill_id=stock_test_bill_id,
            payment_mode="cash"
        )
        print(result)


if __name__ == "__main__":
    main()