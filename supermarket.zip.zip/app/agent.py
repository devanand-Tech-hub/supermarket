import os
from dotenv import load_dotenv
import json

load_dotenv()

from claude_agent_sdk import (
    ClaudeAgentOptions,
    ClaudeSDKClient,
    create_sdk_mcp_server,
    tool,
)

from tools.inventory import (
    add_product,
    receive_stock,
    get_stock,
    get_low_stock,
)

from tools.billing import (
    create_bill,
    add_bill_item,
    get_bill,
    update_bill_item,
    remove_bill_item,
    finalize_bill,
)


# =========================================================
# INVENTORY TOOLS
# =========================================================

@tool(
    "add_product",
    "Add a new supermarket product/SKU to inventory.",
    {
        "name": str,
        "unit": str,
        "cost_price": float,
        "sell_price": float,
        "mrp": float,
        "quantity": float,
        "reorder_level": float,
        "gst_rate": float,
        "hsn_code": str,
    },
)
async def add_product_tool(args: dict) -> dict:

    result = add_product(
        name=args["name"],
        unit=args["unit"],
        cost_price=args["cost_price"],
        sell_price=args["sell_price"],
        mrp=args["mrp"],
        quantity=args["quantity"],
        reorder_level=args["reorder_level"],
        gst_rate=args["gst_rate"],
        hsn_code=args["hsn_code"],
    )

    return {
        "content": [
            {
                "type": "text",
                "text": json.dumps(result),
            }
        ]
    }


@tool(
    "receive_stock",
    "Receive additional stock for an existing product.",
    {
        "product_id": int,
        "quantity": float,
    },
)
async def receive_stock_tool(args: dict) -> dict:

    result = receive_stock(
        product_id=args["product_id"],
        quantity=args["quantity"],
    )

    return {
        "content": [
            {
                "type": "text",
                "text": json.dumps(result),
            }
        ]
    }


@tool(
    "get_stock",
    "Check current stock, price, GST and product information.",
    {
        "product_name": str,
    },
)
async def get_stock_tool(args: dict) -> dict:

    result = get_stock(args["product_name"])

    return {
        "content": [
            {
                "type": "text",
                "text": json.dumps(result),
            }
        ]
    }


@tool(
    "get_low_stock",
    "Find products whose quantity is at or below their reorder level.",
    {},
)
async def get_low_stock_tool(args: dict) -> dict:

    result = get_low_stock()

    return {
        "content": [
            {
                "type": "text",
                "text": json.dumps(result),
            }
        ]
    }


# =========================================================
# BILLING TOOLS
# =========================================================

@tool(
    "create_bill",
    "Create a new draft supermarket bill for a customer.",
    {
        "customer_name": str,
    },
)
async def create_bill_tool(args: dict) -> dict:

    result = create_bill(
        customer_name=args.get("customer_name")
    )

    return {
        "content": [
            {
                "type": "text",
                "text": json.dumps(result),
            }
        ]
    }


@tool(
    "add_bill_item",
    "Add a product and quantity to a draft bill.",
    {
        "bill_id": int,
        "product_id": int,
        "quantity": float,
    },
)
async def add_bill_item_tool(args: dict) -> dict:

    result = add_bill_item(
        bill_id=args["bill_id"],
        product_id=args["product_id"],
        quantity=args["quantity"],
    )

    return {
        "content": [
            {
                "type": "text",
                "text": json.dumps(result),
            }
        ]
    }


@tool(
    "get_bill",
    "Get complete details of a supermarket bill including items, GST and payment status.",
    {
        "bill_id": int,
    },
)
async def get_bill_tool(args: dict) -> dict:

    result = get_bill(
        bill_id=args["bill_id"]
    )

    return {
        "content": [
            {
                "type": "text",
                "text": json.dumps(result)
            }
        ]
    }


@tool(
    "update_bill_item",
    "Change the quantity of an item in a draft bill.",
    {
        "bill_id": int,
        "bill_item_id": int,
        "quantity": float,
    },
)
async def update_bill_item_tool(args: dict) -> dict:

    result = update_bill_item(
        bill_id=args["bill_id"],
        bill_item_id=args["bill_item_id"],
        quantity=args["quantity"],
    )

    return {
        "content": [
            {
                "type": "text",
                "text": json.dumps(result)
            }
        ]
    }


@tool(
    "remove_bill_item",
    "Remove an item from a draft bill.",
    {
        "bill_id": int,
        "bill_item_id": int,
    },
)
async def remove_bill_item_tool(args: dict) -> dict:

    result = remove_bill_item(
        bill_id=args["bill_id"],
        bill_item_id=args["bill_item_id"],
    )

    return {
        "content": [
            {
                "type": "text",
                "text": json.dumps(result)
            }
        ]
    }


@tool(
    "finalize_bill",
    "Finalize a draft bill after receiving sufficient payment. Stock is deducted only when the bill is successfully finalized.",
    {
        "bill_id": int,
        "payment_mode": str,
        "payment_amount": float,
        "payment_reference": str,
    },
)
async def finalize_bill_tool(args: dict) -> dict:

    result = finalize_bill(
        bill_id=args["bill_id"],
        payment_mode=args["payment_mode"],
        payment_amount=args["payment_amount"],
        payment_reference=args.get("payment_reference"),
    )

    return {
        "content": [
            {
                "type": "text",
                "text": json.dumps(result)
            }
        ]
    }


# =========================================================
# INVENTORY MCP SERVER
# =========================================================

inventory_server = create_sdk_mcp_server(
    name="inventory",
    version="1.0.0",
    tools=[
        add_product_tool,
        receive_stock_tool,
        get_stock_tool,
        get_low_stock_tool,
    ],
)


# =========================================================
# BILLING MCP SERVER
# =========================================================

billing_server = create_sdk_mcp_server(
    name="billing",
    version="1.0.0",
    tools=[
        create_bill_tool,
        add_bill_item_tool,
        get_bill_tool,
        update_bill_item_tool,
        remove_bill_item_tool,
        finalize_bill_tool,
    ],
)


# =========================================================
# AGENT CONFIGURATION
# =========================================================

SYSTEM_PROMPT = """
You are Supermarket Ops Agent, an AI assistant for an Indian
kirana/supermarket owner.

The owner communicates in plain, short English.

Your job is to help operate the supermarket through conversation.

IMPORTANT RULES:

1. INVENTORY
- Use inventory tools for inventory information.
- Never invent product names, prices, stock quantities,
  GST rates or HSN codes.
- When the owner asks about stock, use get_stock.
- When the owner asks about low-stock products, use
  get_low_stock.
- When the owner wants to add a product, collect all required
  information before calling add_product.
- When the owner receives stock, use receive_stock.

2. PRODUCT IDENTIFICATION
- Billing tools require product_id.
- If the owner gives a product name instead of an ID,
  first use get_stock to find the product.
- If multiple products with the same or similar name are
  returned, do not guess which one to use.
- Ask the owner to clarify which product they mean.
- Never invent a product_id.

3. BILLING WORKFLOW
A bill normally follows this workflow:

Create Bill
→ Add Items
→ View/Edit/Remove Items if needed
→ Confirm Bill
→ Receive Payment
→ Finalize Bill

4. DRAFT BILLS
- Creating a bill creates a draft bill.
- Adding items to a draft bill does NOT deduct stock.
- Updating or removing items does NOT deduct stock.
- Stock is deducted only when finalize_bill succeeds.

5. BILL ITEMS
- Before adding a product to a bill, make sure the product
  exists and there is enough stock.
- Use add_bill_item for adding products.
- Use update_bill_item when the owner wants to change quantity.
- Use remove_bill_item when the owner wants to remove an item.
- Use get_bill when the owner asks to see the bill.

6. GST
- Billing tools calculate GST automatically.
- Do not manually calculate or invent GST.
- Clearly report subtotal, GST, CGST, SGST and total when
  showing a completed bill.

7. PAYMENT
- A bill must have sufficient payment before it can be finalized.
- Allowed payment modes are:
  cash, upi, card.
- If payment is insufficient, do not try to finalize again
  unless the owner provides a new payment amount.
- If payment is greater than the bill total, tell the owner
  the change amount returned.
- Payment reference is optional.
- Never claim that payment was successful unless
  finalize_bill confirms success.

8. FINALIZED BILLS
- A finalized bill cannot be edited or removed.
- Do not attempt to modify a finalized bill.
- Do not finalize an already finalized bill.

9. AMBIGUOUS REQUESTS
- If a request is genuinely ambiguous, ask the owner for
  clarification instead of guessing.

10. TOOL RESULTS
- Do not pretend that an operation succeeded unless the
  tool confirms success.
- Explain tool results clearly and briefly.

11. IMPORTANT
- Do not use a hardcoded keyword or regex intent router.
- Reason about the owner's request and choose the appropriate
  tool.
"""


# =========================================================
# CREATE AGENT
# =========================================================

options = ClaudeAgentOptions(
    system_prompt=SYSTEM_PROMPT,

    mcp_servers={
        "inventory": inventory_server,
        "billing": billing_server,
    },

    env={
        "ANTHROPIC_API_KEY": os.getenv("ANTHROPIC_API_KEY")
    }
)


# =========================================================
# ASK AGENT
# =========================================================

async def ask_agent(message: str) -> str:

    async with ClaudeSDKClient(options=options) as agent:

        await agent.query(message)

        final_response = ""

        async for response in agent.receive_response():

            if hasattr(response, "content"):

                for block in response.content:

                    if hasattr(block, "text"):
                        final_response += block.text

        return final_response


# =========================================================
# TERMINAL TEST
# =========================================================

async def main():

    print("Supermarket Ops Agent")
    print("Type 'exit' to stop.\n")

    while True:

        message = input("Owner: ")

        if message.lower() == "exit":
            break

        try:

            response = await ask_agent(message)

            print("\nAgent:", response)
            print()

        except Exception as e:

            print("\nError:", e)
            print()


# =========================================================
# RUN
# =========================================================

if __name__ == "__main__":

    import asyncio

    asyncio.run(main())