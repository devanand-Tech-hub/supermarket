from tools.inventory import get_stock, sell_stock, get_low_stock


def main():
    print("\n1. Current stock...")
    stock = get_stock("Maggi 70g")
    print(stock)

    product_id = stock["products"][0]["id"]

    print("\n2. Selling 14 packets...")
    result = sell_stock(product_id, 14)
    print(result)

    print("\n3. Checking low stock...")
    low_stock = get_low_stock()
    print(low_stock)


if __name__ == "__main__":
    main()