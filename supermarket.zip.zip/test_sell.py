from tools.inventory import get_stock, sell_stock


def main():
    print("\n1. Checking current stock...")

    stock = get_stock("Maggi 70g")
    print(stock)

    if not stock["success"]:
        print("Product not found.")
        return

    product_id = stock["products"][0]["id"]
    current_quantity = stock["products"][0]["quantity"]

    print(f"\nCurrent quantity: {current_quantity}")

    print("\n2. Trying to sell 20 packets...")

    result = sell_stock(product_id, 20)
    print(result)

    print("\n3. Checking stock after attempted sale...")

    stock_after = get_stock("Maggi 70g")
    print(stock_after)


if __name__ == "__main__":
    main()